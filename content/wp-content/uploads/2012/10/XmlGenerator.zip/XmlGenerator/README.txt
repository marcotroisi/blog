/*
 *      README.txt
 *      
 *      Copyright 2012 Marco Troisi [inseguitoredidio@gmail.com]
 *      
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *      
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *      
 *      You should have received a copy of the GNU General Public License
 *      along with this program; if not, write to the Free Software
 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
 *      MA 02110-1301, USA.
 */

PLEASE NOTE: This extension for Yii is mostly based on Simon Willison's xmlwriter.php class, which is
freely downloadable on his website (http://simonwillison.net/2003/Apr/29/xmlWriter/). 

What to do:
	
	1) Copy the /extension content on your Yii project's /protected/extensions folder.
	2) Copy the content of my FeedsController.php on your the controller you want to use to 
		generate your feeds.
	3) Beautify the URL to generate this feed using the URL manager in /protected/config/main.php (OPTIONAL)
	
Should you find any problems, contact me at inseguitoredidio@gmail.com. 
