<?php
// Importing the Xml Writer class
Yii::import('application.extensions.xmlgenerator.*');
require_once 'xmlgenerator.php';
// declaring this page as an xml file
header ("Content-Type:text/xml");

class FeedsController extends Controller
{
	public function actionIndex()
	{
		$this->render('index');
	}
	 
	public function actionFeed()
	{
		$xml=new XmlGenerator();
		 // retrieve the latest 20 posts
	    $properties=Properties::model()->findAll(array(
	        'order'=>'id DESC',
	        'limit'=>20,
	    ));
	    
	    $xml->push('trovit');
	    $entries=array();
	    foreach($properties as $property)
	    {	        
	        $xml->push('ad', array('id' => $property->id));
		    $xml->element('name', $property->prezzo);
		    $xml->element('link', $this->createUrl('properties/view',array('id'=>$property->id)));
		    $xml->element('food', $property->data_inserimento);
		    $xml->pop();
	    }
		
		$xml->pop();
		
		echo $xml->getXml();
	}

	// Uncomment the following methods and override them if needed
	/*
	public function filters()
	{
		// return the filter configuration for this controller, e.g.:
		return array(
			'inlineFilterName',
			array(
				'class'=>'path.to.FilterClass',
				'propertyName'=>'propertyValue',
			),
		);
	}

	public function actions()
	{
		// return external action classes, e.g.:
		return array(
			'action1'=>'path.to.ActionClass',
			'action2'=>array(
				'class'=>'path.to.AnotherActionClass',
				'propertyName'=>'propertyValue',
			),
		);
	}
	*/
}
